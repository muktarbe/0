import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {

        

    }
}

     /*    Set<Integer> integers = new HashSet<>();
        integers.add(9);
        integers.add(8);
        integers.add(1);
        integers.add(6);
        for (Integer i:)
        //integers.remove(9);//удаление
        System.out.println(integers);

        Set<Integer> integers1 = new TreeSet<>();
        integers1.add(9);
        integers1.add(8);
        integers1.add(1);
        integers1.add(6);
        System.out.println(integers);//сортоп сактайт
        Random random = new Random();
        int sum = 0;
        List<Integer> list =new ArrayList<>();
        for (int i = 0; i <400 ; i++) {
            list.add(random.nextInt(0,20));
            sum += list.get(i);
        }
       Set<Integer> hashSet = new HashSet<>();
        int sum2 =0;
        hashSet.addAll(list);
        for (Integer i:hashSet){
            sum2+=i;
        }
        //System.out.println(sum);
        //System.out.println(sum2);   */